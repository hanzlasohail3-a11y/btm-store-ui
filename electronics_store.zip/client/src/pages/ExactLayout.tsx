import { Search, User, ShoppingBag, Package, ChevronLeft, ChevronRight, Facebook } from 'lucide-react';
import { useRef, useState, useEffect } from 'react';
import { useProductFilter, Product } from '@/hooks/useProductFilter';
import ProductModal from '@/components/ProductModal';
import { useCart } from '@/contexts/CartContext';

// Sample products with category and manufacturer data
const SAMPLE_PRODUCTS: Product[] = [
  {
    id: 1,
    name: 'ATmega328P Microcontroller',
    specs: 'IC technical Specs',
    price: 25,
    inStock: true,
    category: 'Microcontrollers',
    manufacturer: 'Atmel',
  },
  {
    id: 2,
    name: 'STM32F4 Discovery Board',
    specs: 'IC technical Specs',
    price: 45,
    inStock: true,
    category: 'Microcontrollers',
    manufacturer: 'STMicroelectronics',
  },
  {
    id: 3,
    name: 'NXP LPC1768 ARM Cortex',
    specs: 'IC technical Specs',
    price: 35,
    inStock: true,
    category: 'Microcontrollers',
    manufacturer: 'NXP',
  },
  {
    id: 4,
    name: '74HC595 Shift Register',
    specs: 'IC technical Specs',
    price: 8,
    inStock: true,
    category: 'Logic ICs',
    manufacturer: 'TI',
  },
  {
    id: 5,
    name: 'LM358 Op-Amp',
    specs: 'IC technical Specs',
    price: 5,
    inStock: true,
    category: 'Analog ICs',
    manufacturer: 'TI',
  },
  {
    id: 6,
    name: 'AMS1117 Voltage Regulator',
    specs: 'IC technical Specs',
    price: 3,
    inStock: true,
    category: 'Power Management',
    manufacturer: 'AMS',
  },
  {
    id: 7,
    name: 'Arduino Uno R3',
    specs: 'IC technical Specs',
    price: 120,
    inStock: false,
    category: 'Microcontrollers',
    manufacturer: 'Arduino',
  },
  {
    id: 8,
    name: 'Raspberry Pi 4',
    specs: 'IC technical Specs',
    price: 85,
    inStock: true,
    category: 'Microcontrollers',
    manufacturer: 'Raspberry Pi',
  },
];

const filterSections = [
  {
    title: 'Component Type',
    items: ['Microcontrollers', 'Logic ICs', 'Analog ICs', 'Power Management'],
    filterKey: 'category',
  },
  {
    title: 'Manufacturer',
    items: ['Atmel', 'TI', 'NXP', 'STMicroelectronics', 'Arduino', 'Raspberry Pi', 'AMS'],
    filterKey: 'manufacturer',
  },
  {
    title: 'Price Range',
    items: [
      { label: 'Under $10', value: 'under10' },
      { label: '$10-$50', value: '10-50' },
      { label: '$50-$100', value: '50-100' },
      { label: 'Over $100', value: 'over100' },
    ],
    filterKey: 'priceRange',
  },
  {
    title: 'Availability',
    items: [
      { label: 'In Stock', value: 'in-stock' },
      { label: 'Pre-order', value: 'pre-order' },
    ],
    filterKey: 'availability',
  },
];

export default function ExactLayout() {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState(0);
  const { getTotalItems, addToCart } = useCart();

  const {
    filteredProducts,
    filters,
    setSearchQuery,
    setSortBy,
    toggleCategory,
    toggleManufacturer,
    togglePriceRange,
    toggleAvailability,
  } = useProductFilter(SAMPLE_PRODUCTS);

  const cardsPerPage = 5;
  const totalPages = Math.ceil(filteredProducts.length / cardsPerPage);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      scrollRef.current.scrollBy({
        left: direction === 'left' ? -300 : 300,
        behavior: 'smooth',
      });
    }
  };

  const handleProductClick = (product: Product) => {
    setSelectedProduct(product);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedProduct(null);
  };

  const handleAddToCart = (product: Product, e: React.MouseEvent) => {
    e.stopPropagation();
    addToCart(product.id, product.name, product.price);
  };

  return (
    <div className="w-full bg-white">
      {/* ===== HEADER (Full-width, sticky) ===== */}
      <header className="sticky top-0 z-50 w-full bg-[#2C3E50] border-b border-gray-700">
        <div className="max-w-[1280px] mx-auto px-8 h-20 flex items-center">
          {/* Left: Logo */}
          <div className="text-white text-3xl font-bold tracking-tight flex-shrink-0">
            BTM◆
          </div>

          {/* Center: Search Bar */}
          <div className="flex-1 flex justify-center mx-12">
            <div className="w-full max-w-md relative">
              <input
                type="text"
                placeholder="Search..."
                value={filters.searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full px-4 py-2 bg-[#3D5A73] text-white placeholder-gray-300 rounded-lg border border-[#5A7A99] focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
              <Search className="absolute right-3 top-2.5 w-5 h-5 text-gray-400" />
            </div>
          </div>

          {/* Right: Account, Orders, Cart */}
          <div className="flex-shrink-0 flex items-center gap-8">
            <div className="flex items-center gap-2 text-white cursor-pointer hover:text-orange-500 transition">
              <User className="w-5 h-5" />
              <span className="text-sm font-medium">My Account</span>
            </div>
            <div className="flex items-center gap-2 text-white cursor-pointer hover:text-orange-500 transition">
              <Package className="w-5 h-5" />
              <span className="text-sm font-medium">Orders</span>
            </div>
            <div className="relative flex items-center gap-2 text-white cursor-pointer hover:text-orange-500 transition">
              <ShoppingBag className="w-5 h-5" />
              <span className="text-sm font-medium">Cart</span>
              {getTotalItems() > 0 && (
                <span className="absolute -top-3 -right-3 bg-orange-500 text-white text-xs font-bold w-6 h-6 rounded-full flex items-center justify-center">
                  {getTotalItems()}
                </span>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* ===== HERO SECTION (Full-width, vertically centered) ===== */}
      <section className="w-full bg-[#2C3E50]">
        <div className="max-w-[1280px] mx-auto px-8 py-24 flex items-center gap-16">
          {/* Left: Text Content */}
          <div className="w-1/2 flex flex-col justify-center">
            <h1 className="text-6xl font-bold text-white mb-8 leading-tight tracking-tight">
              PRECISION<br />
              COMPONENTS<br />
              FOR INFINITE<br />
              INNOVATION
            </h1>
            <p className="text-gray-300 text-base mb-10 leading-relaxed">
              Your trusted source for ICs and PCB components
            </p>
            <button className="bg-orange-500 hover:bg-orange-600 text-white font-bold py-3 px-8 rounded transition w-fit">
              BROWSE FULL INVENTORY
            </button>
          </div>

          {/* Right: Image */}
          <div className="w-1/2">
            <img
              src="https://d2xsxph8kpxj0f.cloudfront.net/310519663544340618/FBKg9EQwPBQ2VsXjCGoBKQ/hero-microchip-asM2cWJFbrqnuZX7RavBfP.webp"
              alt="Microchip"
              className="w-full h-auto object-cover rounded-lg"
            />
          </div>
        </div>
      </section>

      {/* ===== MAIN CONTENT AREA (Sidebar + Products) ===== */}
      <section className="w-full bg-gray-50">
        <div className="max-w-[1280px] mx-auto px-8 py-16">
          {/* Two-column layout: Sidebar + Products */}
          <div className="flex gap-8">
            {/* LEFT: Sidebar (Fixed width) */}
            <div className="w-64 flex-shrink-0">
              <div className="bg-white rounded-lg border border-gray-300 p-8">
                <h3 className="text-gray-900 font-bold text-lg mb-8">Filtering</h3>

                {filterSections.map((section, idx) => (
                  <div key={idx} className={idx > 0 ? 'border-t border-gray-200 pt-6 mt-6' : ''}>
                    <h4 className="text-gray-800 font-semibold text-sm mb-4 uppercase tracking-wide">
                      {section.title}
                    </h4>
                    <div className="space-y-3">
                      {section.items.map((item, itemIdx) => {
                        const itemLabel = typeof item === 'string' ? item : item.label;
                        const itemValue = typeof item === 'string' ? item : item.value;
                        let isChecked = false;

                        if (section.filterKey === 'category') {
                          isChecked = filters.selectedCategories.has(itemLabel);
                        } else if (section.filterKey === 'manufacturer') {
                          isChecked = filters.selectedManufacturers.has(itemLabel);
                        } else if (section.filterKey === 'priceRange') {
                          isChecked = filters.selectedPriceRanges.has(itemValue);
                        } else if (section.filterKey === 'availability') {
                          isChecked = filters.selectedAvailability.has(itemValue);
                        }

                        const handleChange = () => {
                          if (section.filterKey === 'category') {
                            toggleCategory(itemLabel);
                          } else if (section.filterKey === 'manufacturer') {
                            toggleManufacturer(itemLabel);
                          } else if (section.filterKey === 'priceRange') {
                            togglePriceRange(itemValue);
                          } else if (section.filterKey === 'availability') {
                            toggleAvailability(itemValue);
                          }
                        };

                        return (
                          <label key={itemIdx} className="flex items-center gap-3 cursor-pointer group">
                            <input
                              type="checkbox"
                              checked={isChecked}
                              onChange={handleChange}
                              className="w-4 h-4 rounded border-gray-300 text-orange-500 focus:ring-orange-500"
                            />
                            <span className="text-gray-700 text-sm group-hover:text-gray-900">
                              {itemLabel}
                            </span>
                          </label>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* RIGHT: Product Section */}
            <div className="flex-1">
              {/* Title and Sort Controls */}
              <div className="flex items-center justify-between mb-8">
                <h2 className="text-3xl font-bold text-gray-900 tracking-wide">
                  FEATURED COMPONENTS ({filteredProducts.length})
                </h2>
                <select
                  value={filters.sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="px-4 py-2 bg-white border border-gray-300 rounded text-gray-700 text-sm focus:outline-none focus:ring-2 focus:ring-orange-500"
                >
                  <option value="relevance">Sort: Relevance</option>
                  <option value="price-low">Price: Low to High</option>
                  <option value="price-high">Price: High to Low</option>
                  <option value="newest">Newest</option>
                  <option value="popular">Most Popular</option>
                </select>
              </div>

              {/* Carousel Container */}
              {filteredProducts.length > 0 ? (
                <div>
                  <div className="flex items-center gap-6 mb-6">
                    {/* Left Arrow */}
                    <button
                      onClick={() => scroll('left')}
                      className="flex-shrink-0 bg-yellow-400 hover:bg-yellow-500 text-gray-800 p-3 rounded-full transition shadow-md"
                    >
                      <ChevronLeft className="w-6 h-6" />
                    </button>

                    {/* Products Scroll Area */}
                    <div className="flex-1 overflow-x-auto">
                      <div
                        ref={scrollRef}
                        className="inline-flex gap-6 pb-2"
                        style={{ scrollBehavior: 'smooth' }}
                      >
                        {filteredProducts.map((product) => (
                          <div
                            key={product.id}
                            onClick={() => handleProductClick(product)}
                            className="flex-shrink-0 w-48 bg-white rounded-lg border border-gray-300 overflow-hidden hover:shadow-lg transition cursor-pointer"
                          >
                            {/* Product Image */}
                            <div className="w-full h-32 bg-gray-200 flex items-center justify-center overflow-hidden">
                              <img
                                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663544340618/FBKg9EQwPBQ2VsXjCGoBKQ/electronics-components-7zymWBmLxNTSvRKjSuGGNc.webp"
                                alt={product.name}
                                className="w-full h-full object-cover"
                              />
                            </div>

                            {/* Product Info */}
                            <div className="p-4">
                              <h4 className="text-sm font-semibold text-gray-800 line-clamp-2 mb-1">
                                {product.name}
                              </h4>
                              <p className="text-xs text-gray-600 mb-3">{product.specs}</p>

                              {/* Stock Badge */}
                              {product.inStock && (
                                <div className="inline-block bg-yellow-300 text-gray-800 text-xs font-bold px-2 py-1 rounded mb-3">
                                  In Stock
                                </div>
                              )}

                              {/* Price and Button */}
                              <div className="flex items-center justify-between mt-4">
                                <span className="text-lg font-bold text-gray-800">${product.price}</span>
                                <button
                                  onClick={(e) => handleAddToCart(product, e)}
                                  className="bg-orange-500 hover:bg-orange-600 text-white font-bold py-2 px-3 rounded transition text-xs"
                                >
                                  ADD TO CART
                                </button>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Right Arrow */}
                    <button
                      onClick={() => scroll('right')}
                      className="flex-shrink-0 bg-yellow-400 hover:bg-yellow-500 text-gray-800 p-3 rounded-full transition shadow-md"
                    >
                      <ChevronRight className="w-6 h-6" />
                    </button>
                  </div>

                  {/* Pagination Dots */}
                  {totalPages > 1 && (
                    <div className="flex justify-center gap-2 mt-4">
                      {Array.from({ length: totalPages }).map((_, idx) => (
                        <button
                          key={idx}
                          onClick={() => setCurrentPage(idx)}
                          className={`w-2 h-2 rounded-full transition ${
                            idx === currentPage ? 'bg-orange-500' : 'bg-gray-300'
                          }`}
                          aria-label={`Go to page ${idx + 1}`}
                        />
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-center py-12">
                  <p className="text-gray-600 text-lg">No products match your filters</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* ===== FOOTER (Full-width) ===== */}
      <footer className="w-full bg-[#2C3E50] border-t-8 border-gray-300">
        <div className="max-w-[1280px] mx-auto px-8 py-12 flex items-center justify-between">
          {/* Left Links */}
          <div className="flex gap-8">
            <a href="#" className="text-white text-sm hover:text-orange-500 transition underline">
              About
            </a>
            <a href="#" className="text-white text-sm hover:text-orange-500 transition underline">
              Support
            </a>
            <a href="#" className="text-white text-sm hover:text-orange-500 transition underline">
              Contact
            </a>
            <a href="#" className="text-white text-sm hover:text-orange-500 transition underline">
              Privacy
            </a>
          </div>



          {/* Right Social */}
          <button className="text-white hover:text-orange-500 transition">
            <Facebook className="w-5 h-5" />
          </button>
        </div>
      </footer>

      {/* Product Modal */}
      <ProductModal product={selectedProduct} isOpen={isModalOpen} onClose={handleCloseModal} />
    </div>
  );
}
