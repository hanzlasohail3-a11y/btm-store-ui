import { useState, useMemo } from 'react';

export interface Product {
  id: number;
  name: string;
  specs: string;
  price: number;
  inStock: boolean;
  category?: string;
  manufacturer?: string;
}

export type SortOption = 'relevance' | 'price-low' | 'price-high' | 'newest' | 'popular';

export interface FilterState {
  searchQuery: string;
  selectedCategories: Set<string>;
  selectedManufacturers: Set<string>;
  selectedPriceRanges: Set<string>;
  selectedAvailability: Set<string>;
  sortBy: SortOption;
}

export function useProductFilter(allProducts: Product[]) {
  const [filters, setFilters] = useState<FilterState>({
    searchQuery: '',
    selectedCategories: new Set(),
    selectedManufacturers: new Set(),
    selectedPriceRanges: new Set(),
    selectedAvailability: new Set(),
    sortBy: 'relevance',
  });

  // Step 1 & 2: Apply filters and search
  const filteredProducts = useMemo(() => {
    return allProducts.filter((product) => {
      // Search filter
      if (filters.searchQuery.trim()) {
        const query = filters.searchQuery.toLowerCase();
        const matchesSearch =
          product.name.toLowerCase().includes(query) ||
          product.specs.toLowerCase().includes(query);
        if (!matchesSearch) return false;
      }

      // Category filter
      if (filters.selectedCategories.size > 0) {
        if (!product.category || !filters.selectedCategories.has(product.category)) {
          return false;
        }
      }

      // Manufacturer filter
      if (filters.selectedManufacturers.size > 0) {
        if (!product.manufacturer || !filters.selectedManufacturers.has(product.manufacturer)) {
          return false;
        }
      }

      // Price range filter
      if (filters.selectedPriceRanges.size > 0) {
        let priceMatches = false;
        filters.selectedPriceRanges.forEach((range) => {
          if (range === 'under10' && product.price < 10) priceMatches = true;
          if (range === '10-50' && product.price >= 10 && product.price <= 50) priceMatches = true;
          if (range === '50-100' && product.price > 50 && product.price <= 100) priceMatches = true;
          if (range === 'over100' && product.price > 100) priceMatches = true;
        });
        if (!priceMatches) return false;
      }

      // Availability filter
      if (filters.selectedAvailability.size > 0) {
        let availabilityMatches = false;
        filters.selectedAvailability.forEach((status) => {
          if (status === 'in-stock' && product.inStock) availabilityMatches = true;
          if (status === 'pre-order' && !product.inStock) availabilityMatches = true;
        });
        if (!availabilityMatches) return false;
      }

      return true;
    });
  }, [allProducts, filters]);

  // Step 3: Apply sorting
  const sortedAndFilteredProducts = useMemo(() => {
    const sorted = [...filteredProducts];

    switch (filters.sortBy) {
      case 'price-low':
        sorted.sort((a, b) => a.price - b.price);
        break;
      case 'price-high':
        sorted.sort((a, b) => b.price - a.price);
        break;
      case 'newest':
        sorted.sort((a, b) => b.id - a.id);
        break;
      case 'popular':
        // Mock popularity by stock status (in-stock first)
        sorted.sort((a, b) => (b.inStock ? 1 : 0) - (a.inStock ? 1 : 0));
        break;
      case 'relevance':
      default:
        // Keep original order
        break;
    }

    return sorted;
  }, [filteredProducts, filters.sortBy]);

  // Update search query
  const setSearchQuery = (query: string) => {
    setFilters((prev) => ({
      ...prev,
      searchQuery: query,
    }));
  };

  // Update sort option
  const setSortBy = (sortOption: SortOption) => {
    setFilters((prev) => ({
      ...prev,
      sortBy: sortOption,
    }));
  };

  // Toggle category filter
  const toggleCategory = (category: string) => {
    setFilters((prev) => {
      const newCategories = new Set(prev.selectedCategories);
      if (newCategories.has(category)) {
        newCategories.delete(category);
      } else {
        newCategories.add(category);
      }
      return { ...prev, selectedCategories: newCategories };
    });
  };

  // Toggle manufacturer filter
  const toggleManufacturer = (manufacturer: string) => {
    setFilters((prev) => {
      const newManufacturers = new Set(prev.selectedManufacturers);
      if (newManufacturers.has(manufacturer)) {
        newManufacturers.delete(manufacturer);
      } else {
        newManufacturers.add(manufacturer);
      }
      return { ...prev, selectedManufacturers: newManufacturers };
    });
  };

  // Toggle price range filter
  const togglePriceRange = (range: string) => {
    setFilters((prev) => {
      const newRanges = new Set(prev.selectedPriceRanges);
      if (newRanges.has(range)) {
        newRanges.delete(range);
      } else {
        newRanges.add(range);
      }
      return { ...prev, selectedPriceRanges: newRanges };
    });
  };

  // Toggle availability filter
  const toggleAvailability = (status: string) => {
    setFilters((prev) => {
      const newAvailability = new Set(prev.selectedAvailability);
      if (newAvailability.has(status)) {
        newAvailability.delete(status);
      } else {
        newAvailability.add(status);
      }
      return { ...prev, selectedAvailability: newAvailability };
    });
  };

  return {
    filteredProducts: sortedAndFilteredProducts,
    filters,
    setSearchQuery,
    setSortBy,
    toggleCategory,
    toggleManufacturer,
    togglePriceRange,
    toggleAvailability,
  };
}
