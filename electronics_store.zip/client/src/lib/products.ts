export interface Product {
  id: string;
  name: string;
  category: string;
  manufacturer: string;
  price: number;
  stock: number;
  description: string;
  specs: string[];
  image: string;
}

export const products: Product[] = [
  {
    id: '1',
    name: 'ATmega328P Microcontroller',
    category: 'Microcontrollers',
    manufacturer: 'Atmel',
    price: 3.50,
    stock: 245,
    description: '8-bit AVR microcontroller with 32KB flash memory',
    specs: ['32KB Flash', '2KB SRAM', '1KB EEPROM', '20MHz'],
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544340618/FBKg9EQwPBQ2VsXjCGoBKQ/hero-microchip-asM2cWJFbrqnuZX7RavBfP.webp',
  },
  {
    id: '2',
    name: 'STM32F103C8T6 ARM Cortex-M3',
    category: 'Microcontrollers',
    manufacturer: 'STMicroelectronics',
    price: 4.25,
    stock: 189,
    description: '32-bit ARM Cortex-M3 processor with 64KB flash',
    specs: ['64KB Flash', '20KB SRAM', '72MHz', 'USB 2.0'],
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544340618/FBKg9EQwPBQ2VsXjCGoBKQ/pcb-circuit-board-TYeTEoUxc3W697fJX5AL6u.webp',
  },
  {
    id: '3',
    name: '74HC595 Shift Register',
    category: 'Logic ICs',
    manufacturer: 'Texas Instruments',
    price: 0.45,
    stock: 512,
    description: '8-bit parallel-load shift register',
    specs: ['8-bit', '5V Logic', 'DIP-16', 'Parallel Load'],
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544340618/FBKg9EQwPBQ2VsXjCGoBKQ/electronics-components-7zymWBmLxNTSvRKjSuGGNc.webp',
  },
  {
    id: '4',
    name: 'NE555 Timer IC',
    category: 'Analog ICs',
    manufacturer: 'Texas Instruments',
    price: 0.35,
    stock: 678,
    description: 'Precision timing circuit for astable/monostable operation',
    specs: ['DIP-8', '5-15V', 'Precision Timing', 'Low Power'],
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544340618/FBKg9EQwPBQ2VsXjCGoBKQ/hero-microchip-asM2cWJFbrqnuZX7RavBfP.webp',
  },
  {
    id: '5',
    name: 'LM7805 Voltage Regulator',
    category: 'Power Management',
    manufacturer: 'Texas Instruments',
    price: 0.55,
    stock: 423,
    description: '5V linear voltage regulator, 1A output',
    specs: ['5V Output', '1A Max', 'TO-220', 'Thermal Protection'],
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544340618/FBKg9EQwPBQ2VsXjCGoBKQ/pcb-circuit-board-TYeTEoUxc3W697fJX5AL6u.webp',
  },
  {
    id: '6',
    name: 'NAND Flash Memory 32MB',
    category: 'Memory',
    manufacturer: 'Samsung',
    price: 8.99,
    stock: 156,
    description: 'High-speed NAND flash memory module',
    specs: ['32MB', 'SOP-48', '3.3V', '50ns Access Time'],
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544340618/FBKg9EQwPBQ2VsXjCGoBKQ/electronics-components-7zymWBmLxNTSvRKjSuGGNc.webp',
  },
  {
    id: '7',
    name: 'TL072 Dual Op-Amp',
    category: 'Analog ICs',
    manufacturer: 'Texas Instruments',
    price: 0.95,
    stock: 334,
    description: 'Low-noise dual operational amplifier',
    specs: ['Dual Op-Amp', 'DIP-8', 'Low Noise', '±15V Supply'],
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544340618/FBKg9EQwPBQ2VsXjCGoBKQ/hero-microchip-asM2cWJFbrqnuZX7RavBfP.webp',
  },
  {
    id: '8',
    name: 'ESP32 WiFi Module',
    category: 'Wireless Modules',
    manufacturer: 'Espressif',
    price: 6.50,
    stock: 267,
    description: 'Dual-core WiFi and Bluetooth microcontroller',
    specs: ['WiFi 802.11b/g/n', 'Bluetooth 4.2', '240MHz', '520KB SRAM'],
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544340618/FBKg9EQwPBQ2VsXjCGoBKQ/pcb-circuit-board-TYeTEoUxc3W697fJX5AL6u.webp',
  },
  {
    id: '9',
    name: 'SN74LS00 NAND Gate',
    category: 'Logic ICs',
    manufacturer: 'Texas Instruments',
    price: 0.25,
    stock: 891,
    description: 'Quad 2-input NAND gate',
    specs: ['DIP-14', '5V Logic', 'TTL', 'Quad NAND'],
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544340618/FBKg9EQwPBQ2VsXjCGoBKQ/electronics-components-7zymWBmLxNTSvRKjSuGGNc.webp',
  },
  {
    id: '10',
    name: 'ADS1115 ADC Module',
    category: 'Analog Converters',
    manufacturer: 'Texas Instruments',
    price: 3.75,
    stock: 198,
    description: '16-bit I2C analog-to-digital converter',
    specs: ['16-bit', 'I2C', '4-channel', '860 SPS'],
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544340618/FBKg9EQwPBQ2VsXjCGoBKQ/hero-microchip-asM2cWJFbrqnuZX7RavBfP.webp',
  },
  {
    id: '11',
    name: 'MCP23017 I/O Expander',
    category: 'Interface ICs',
    manufacturer: 'Microchip',
    price: 1.85,
    stock: 276,
    description: '16-bit I2C I/O port expander',
    specs: ['16-bit I/O', 'I2C', 'DIP-28', '100kHz I2C'],
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544340618/FBKg9EQwPBQ2VsXjCGoBKQ/pcb-circuit-board-TYeTEoUxc3W697fJX5AL6u.webp',
  },
  {
    id: '12',
    name: 'MAX7219 LED Driver',
    category: 'Display Drivers',
    manufacturer: 'Maxim Integrated',
    price: 2.45,
    stock: 145,
    description: 'Serially interfaced 8-digit LED display driver',
    specs: ['8-digit', 'SPI', 'DIP-24', 'Brightness Control'],
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544340618/FBKg9EQwPBQ2VsXjCGoBKQ/electronics-components-7zymWBmLxNTSvRKjSuGGNc.webp',
  },
];

export const categories = [
  'Microcontrollers',
  'Logic ICs',
  'Analog ICs',
  'Power Management',
  'Memory',
  'Wireless Modules',
  'Analog Converters',
  'Interface ICs',
  'Display Drivers',
];

export const manufacturers = [
  'Atmel',
  'STMicroelectronics',
  'Texas Instruments',
  'Samsung',
  'Espressif',
  'Microchip',
  'Maxim Integrated',
];

export const priceRanges = [
  { label: 'Under $1', min: 0, max: 1 },
  { label: '$1 - $5', min: 1, max: 5 },
  { label: '$5 - $10', min: 5, max: 10 },
  { label: 'Over $10', min: 10, max: Infinity },
];
