import { ShoppingCart, Eye } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Product } from '@/lib/products';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
  onQuickView: (product: Product) => void;
}

export default function ProductCard({
  product,
  onAddToCart,
  onQuickView,
}: ProductCardProps) {
  const inStock = product.stock > 0;
  const lowStock = product.stock > 0 && product.stock <= 10;

  return (
    <div className="bg-card rounded-lg overflow-hidden border border-border hover:border-accent/50 transition-all duration-300 hover:shadow-lg group h-full flex flex-col product-card-enter">
      {/* Image Container */}
      <div className="relative h-48 bg-muted overflow-hidden">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        {/* Stock Badge */}
        <div className="absolute top-3 right-3">
          {inStock ? (
            <div className="tech-badge">
              {lowStock ? '⚠ Low Stock' : '✓ In Stock'}
            </div>
          ) : (
            <div className="inline-flex items-center px-3 py-1 rounded-full text-xs font-mono font-semibold bg-destructive/20 text-destructive">
              Out of Stock
            </div>
          )}
        </div>
        {/* Quick View Button */}
        <button
          onClick={() => onQuickView(product)}
          className="absolute inset-0 bg-black/0 hover:bg-black/40 transition-colors duration-300 flex items-center justify-center opacity-0 group-hover:opacity-100"
        >
          <Eye className="w-6 h-6 text-white" />
        </button>
      </div>

      {/* Content */}
      <div className="p-4 flex-1 flex flex-col">
        {/* Category */}
        <p className="text-xs font-mono text-muted-foreground mb-2 uppercase tracking-wide">
          {product.category}
        </p>

        {/* Product Name */}
        <h3 className="font-semibold text-sm text-foreground mb-2 line-clamp-2">
          {product.name}
        </h3>

        {/* Description */}
        <p className="text-xs text-muted-foreground mb-3 line-clamp-2 flex-1">
          {product.description}
        </p>

        {/* Specs */}
        <div className="mb-4">
          <div className="flex flex-wrap gap-1">
            {product.specs.slice(0, 2).map((spec, idx) => (
              <span
                key={idx}
                className="text-xs font-mono bg-muted text-muted-foreground px-2 py-1 rounded"
              >
                {spec}
              </span>
            ))}
            {product.specs.length > 2 && (
              <span className="text-xs font-mono bg-muted text-muted-foreground px-2 py-1 rounded">
                +{product.specs.length - 2}
              </span>
            )}
          </div>
        </div>

        {/* Price and CTA */}
        <div className="flex items-center justify-between pt-4 border-t border-border">
          <div className="flex flex-col">
            <span className="text-xs text-muted-foreground font-mono">Price</span>
            <span className="text-lg font-bold text-foreground">
              ${product.price.toFixed(2)}
            </span>
          </div>
          <Button
            onClick={() => onAddToCart(product)}
            disabled={!inStock}
            size="sm"
            className="bg-accent hover:bg-accent/90 text-accent-foreground disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <ShoppingCart className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
