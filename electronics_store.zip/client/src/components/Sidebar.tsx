import { X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { categories, manufacturers, priceRanges } from '@/lib/products';

interface SidebarProps {
  selectedCategories: string[];
  selectedManufacturers: string[];
  selectedPriceRange: string;
  onCategoryChange: (category: string) => void;
  onManufacturerChange: (manufacturer: string) => void;
  onPriceRangeChange: (range: string) => void;
  onClose?: () => void;
  isOpen?: boolean;
}

export default function Sidebar({
  selectedCategories,
  selectedManufacturers,
  selectedPriceRange,
  onCategoryChange,
  onManufacturerChange,
  onPriceRangeChange,
  onClose,
  isOpen = true,
}: SidebarProps) {
  return (
    <>
      {/* Mobile Overlay */}
      {isOpen && onClose && (
        <div
          className="fixed inset-0 bg-black/50 md:hidden z-40"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed md:relative top-0 left-0 h-screen md:h-auto w-64 bg-card border-r border-border overflow-y-auto transition-transform duration-300 z-40 md:z-0 ${
          isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        }`}
      >
        <div className="p-6 space-y-6">
          {/* Close Button - Mobile */}
          {onClose && (
            <button
              onClick={onClose}
              className="md:hidden absolute top-4 right-4 p-2 hover:bg-muted rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>
          )}

          {/* Component Type */}
          <div>
            <h3 className="font-semibold text-foreground mb-3 text-sm uppercase tracking-wide">
              Component Type
            </h3>
            <div className="space-y-2">
              {categories.map((category) => (
                <label
                  key={category}
                  className="flex items-center gap-3 cursor-pointer group"
                >
                  <input
                    type="checkbox"
                    checked={selectedCategories.includes(category)}
                    onChange={() => onCategoryChange(category)}
                    className="w-4 h-4 rounded border-border text-accent focus:ring-accent"
                  />
                  <span className="text-sm text-muted-foreground group-hover:text-foreground transition-colors">
                    {category}
                  </span>
                </label>
              ))}
            </div>
          </div>

          {/* Divider */}
          <div className="h-px bg-border" />

          {/* Manufacturer */}
          <div>
            <h3 className="font-semibold text-foreground mb-3 text-sm uppercase tracking-wide">
              Manufacturer
            </h3>
            <div className="space-y-2">
              {manufacturers.map((manufacturer) => (
                <label
                  key={manufacturer}
                  className="flex items-center gap-3 cursor-pointer group"
                >
                  <input
                    type="checkbox"
                    checked={selectedManufacturers.includes(manufacturer)}
                    onChange={() => onManufacturerChange(manufacturer)}
                    className="w-4 h-4 rounded border-border text-accent focus:ring-accent"
                  />
                  <span className="text-sm text-muted-foreground group-hover:text-foreground transition-colors">
                    {manufacturer}
                  </span>
                </label>
              ))}
            </div>
          </div>

          {/* Divider */}
          <div className="h-px bg-border" />

          {/* Price Range */}
          <div>
            <h3 className="font-semibold text-foreground mb-3 text-sm uppercase tracking-wide">
              Price Range
            </h3>
            <div className="space-y-2">
              {priceRanges.map((range) => (
                <label
                  key={range.label}
                  className="flex items-center gap-3 cursor-pointer group"
                >
                  <input
                    type="radio"
                    name="price-range"
                    value={range.label}
                    checked={selectedPriceRange === range.label}
                    onChange={() => onPriceRangeChange(range.label)}
                    className="w-4 h-4 border-border text-accent focus:ring-accent"
                  />
                  <span className="text-sm text-muted-foreground group-hover:text-foreground transition-colors">
                    {range.label}
                  </span>
                </label>
              ))}
            </div>
          </div>

          {/* Divider */}
          <div className="h-px bg-border" />

          {/* Clear Filters */}
          {(selectedCategories.length > 0 ||
            selectedManufacturers.length > 0 ||
            selectedPriceRange) && (
            <Button
              onClick={() => {
                selectedCategories.forEach(onCategoryChange);
                selectedManufacturers.forEach(onManufacturerChange);
                onPriceRangeChange('');
              }}
              variant="outline"
              size="sm"
              className="w-full"
            >
              Clear Filters
            </Button>
          )}
        </div>
      </aside>
    </>
  );
}
