import { Search, User, ShoppingBag, Package } from 'lucide-react';

interface ExactHeaderProps {
  cartCount?: number;
}

export default function ExactHeader({ cartCount = 0 }: ExactHeaderProps) {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-[#2C3E50] h-20 flex items-center px-8">
      {/* Left: Logo */}
      <div className="flex-shrink-0">
        <div className="text-white text-3xl font-bold tracking-tight">
          BTM<span className="text-orange-500">◆</span>
        </div>
      </div>

      {/* Center: Search Bar */}
      <div className="flex-1 flex justify-center mx-12">
        <div className="w-full max-w-md relative">
          <input
            type="text"
            placeholder="Search..."
            className="w-full px-4 py-2 bg-[#3D5A73] text-white placeholder-gray-300 rounded-lg border border-[#5A7A99] focus:outline-none focus:ring-2 focus:ring-orange-500"
          />
          <Search className="absolute right-3 top-2.5 w-5 h-5 text-gray-400" />
        </div>
      </div>

      {/* Right: Account, Orders, Cart */}
      <div className="flex-shrink-0 flex items-center gap-8">
        {/* My Account */}
        <div className="flex items-center gap-2 text-white cursor-pointer hover:text-orange-500 transition">
          <User className="w-5 h-5" />
          <span className="text-sm font-medium">My Account</span>
        </div>

        {/* Orders */}
        <div className="flex items-center gap-2 text-white cursor-pointer hover:text-orange-500 transition">
          <Package className="w-5 h-5" />
          <span className="text-sm font-medium">Orders</span>
        </div>

        {/* Cart */}
        <div className="relative flex items-center gap-2 text-white cursor-pointer hover:text-orange-500 transition">
          <ShoppingBag className="w-5 h-5" />
          <span className="text-sm font-medium">Cart</span>
          {cartCount > 0 && (
            <span className="absolute -top-2 -right-2 bg-blue-500 text-white text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center">
              {cartCount}
            </span>
          )}
        </div>
      </div>
    </header>
  );
}
