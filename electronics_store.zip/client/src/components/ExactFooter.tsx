import { Facebook } from 'lucide-react';

export default function ExactFooter() {
  return (
    <footer className="fixed bottom-[120px] left-0 right-0 h-16 bg-[#2C3E50] flex items-center justify-between px-8 border-t border-gray-600">
      {/* Left Links */}
      <div className="flex gap-8">
        <a href="#" className="text-white text-sm hover:text-orange-500 transition underline">
          About
        </a>
        <a href="#" className="text-white text-sm hover:text-orange-500 transition underline">
          Support
        </a>
        <a href="#" className="text-white text-sm hover:text-orange-500 transition underline">
          Contact
        </a>
        <a href="#" className="text-white text-sm hover:text-orange-500 transition underline">
          Privacy
        </a>
      </div>

      {/* Center Decorative Elements */}
      <div className="flex gap-2">
        <div className="w-4 h-4 bg-yellow-400 rounded" />
        <div className="w-4 h-4 bg-yellow-400 rounded" />
      </div>

      {/* Right Social */}
      <button className="text-white hover:text-orange-500 transition">
        <Facebook className="w-5 h-5" />
      </button>
    </footer>
  );
}
