import { Button } from '@/components/ui/button';

interface HeroProps {
  onBrowseClick: () => void;
}

export default function Hero({ onBrowseClick }: HeroProps) {
  return (
    <section className="relative w-full overflow-hidden bg-background">
      {/* Background Image with Overlay */}
      <div className="relative h-96 md:h-[500px] w-full">
        <img
          src="https://d2xsxph8kpxj0f.cloudfront.net/310519663544340618/FBKg9EQwPBQ2VsXjCGoBKQ/hero-microchip-asM2cWJFbrqnuZX7RavBfP.webp"
          alt="Microchip PCB"
          className="w-full h-full object-cover"
        />
        {/* Dark Overlay */}
        <div className="absolute inset-0 bg-black/40" />
      </div>

      {/* Content Overlay */}
      <div className="absolute inset-0 flex items-center">
        <div className="container">
          <div className="max-w-2xl">
            <h1 className="text-4xl md:text-5xl font-bold text-white mb-4 leading-tight">
              Precision Components for Infinite Innovation
            </h1>
            <p className="text-lg md:text-xl text-gray-100 mb-8 font-light">
              Your trusted source for ICs and PCB components. Quality parts, competitive prices, fast delivery.
            </p>
            <Button
              onClick={onBrowseClick}
              size="lg"
              className="bg-accent hover:bg-accent/90 text-accent-foreground font-semibold px-8"
            >
              Browse Full Inventory
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
