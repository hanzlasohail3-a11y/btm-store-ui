import { ChevronLeft, ChevronRight, ShoppingCart } from 'lucide-react';
import { useRef } from 'react';

const products = [
  {
    id: 1,
    name: 'ATmega328P Microcontroller',
    specs: 'IC technical Specs',
    price: 300,
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544340618/FBKg9EQwPBQ2VsXjCGoBKQ/electronics-components-7zymWBmLxNTSvRKjSuGGNc.webp',
  },
  {
    id: 2,
    name: 'ATmega328P Microcontroller',
    specs: 'IC technical Specs',
    price: 300,
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544340618/FBKg9EQwPBQ2VsXjCGoBKQ/electronics-components-7zymWBmLxNTSvRKjSuGGNc.webp',
  },
  {
    id: 3,
    name: 'ATmega328P Microcontroller',
    specs: 'IC technical Specs',
    price: 300,
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544340618/FBKg9EQwPBQ2VsXjCGoBKQ/electronics-components-7zymWBmLxNTSvRKjSuGGNc.webp',
  },
  {
    id: 4,
    name: 'ATmega328P Microcontroller',
    specs: 'IC technical Specs',
    price: 300,
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544340618/FBKg9EQwPBQ2VsXjCGoBKQ/electronics-components-7zymWBmLxNTSvRKjSuGGNc.webp',
  },
  {
    id: 5,
    name: 'ATmega328P Microcontroller',
    specs: 'IC technical Specs',
    price: 300,
    image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663544340618/FBKg9EQwPBQ2VsXjCGoBKQ/electronics-components-7zymWBmLxNTSvRKjSuGGNc.webp',
  },
];

export default function ExactProducts() {
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = 300;
      scrollRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth',
      });
    }
  };

  return (
    <section className="fixed bottom-0 left-0 right-0 h-[120px] bg-gray-100 flex items-center px-8 border-t border-gray-300">
      {/* Left Sidebar - Filtering */}
      <div className="w-48 flex-shrink-0 pr-8">
        <h3 className="text-gray-700 font-semibold mb-4">Filtering</h3>
        <div className="space-y-3">
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="text-gray-600 text-sm cursor-pointer hover:text-gray-900">
              Text
            </div>
          ))}
        </div>
      </div>

      {/* Center - Featured Components */}
      <div className="flex-1 flex items-center gap-4">
        {/* Left Arrow */}
        <button
          onClick={() => scroll('left')}
          className="flex-shrink-0 bg-yellow-400 hover:bg-yellow-500 text-gray-800 p-3 rounded-full transition"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>

        {/* Products Scroll Container */}
        <div className="flex-1 overflow-hidden">
          <div
            ref={scrollRef}
            className="flex gap-4 overflow-x-auto scroll-smooth"
            style={{ scrollBehavior: 'smooth' }}
          >
            {products.map((product) => (
              <div
                key={product.id}
                className="flex-shrink-0 w-40 bg-white rounded-lg border border-gray-300 overflow-hidden hover:shadow-lg transition"
              >
                <div className="w-full h-24 bg-gray-200 flex items-center justify-center overflow-hidden">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-3">
                  <h4 className="text-xs font-semibold text-gray-800 line-clamp-2">
                    {product.name}
                  </h4>
                  <p className="text-xs text-gray-600 mb-2">{product.specs}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-gray-800">${product.price}</span>
                    <button className="bg-orange-500 hover:bg-orange-600 text-white p-1 rounded transition">
                      <ShoppingCart className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Arrow */}
        <button
          onClick={() => scroll('right')}
          className="flex-shrink-0 bg-yellow-400 hover:bg-yellow-500 text-gray-800 p-3 rounded-full transition"
        >
          <ChevronRight className="w-6 h-6" />
        </button>
      </div>
    </section>
  );
}
