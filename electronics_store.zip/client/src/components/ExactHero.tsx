export default function ExactHero() {
  return (
    <section className="fixed top-20 left-0 right-0 h-[calc(100vh-80px-120px)] bg-[#2C3E50] flex items-center overflow-hidden">
      {/* Left Content */}
      <div className="w-1/2 px-12 z-10">
        <h1 className="text-5xl font-bold text-white mb-6 leading-tight tracking-tight">
          PRECISION COMPONENTS<br />
          FOR INFINITE INNOVATION
        </h1>
        <p className="text-gray-300 text-lg mb-8">
          Your trusted source for ICs and PCB components
        </p>
        <button className="bg-orange-500 hover:bg-orange-600 text-white font-bold py-3 px-8 rounded transition">
          BROWSE FULL INVENTORY
        </button>
      </div>

      {/* Right Image */}
      <div className="w-1/2 flex items-center justify-center">
        <img
          src="https://d2xsxph8kpxj0f.cloudfront.net/310519663544340618/FBKg9EQwPBQ2VsXjCGoBKQ/hero-microchip-asM2cWJFbrqnuZX7RavBfP.webp"
          alt="Microchip"
          className="w-full h-full object-cover"
        />
      </div>
    </section>
  );
}
