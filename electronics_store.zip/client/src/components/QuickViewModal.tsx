import { X, ShoppingCart, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Product } from '@/lib/products';
import { useState } from 'react';

interface QuickViewModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onAddToCart: (product: Product) => void;
}

export default function QuickViewModal({
  product,
  isOpen,
  onClose,
  onAddToCart,
}: QuickViewModalProps) {
  const [added, setAdded] = useState(false);

  if (!isOpen || !product) return null;

  const handleAddToCart = () => {
    onAddToCart(product);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  const inStock = product.stock > 0;

  return (
    <>
      {/* Overlay */}
      <div
        className="fixed inset-0 bg-black/50 z-50 transition-opacity"
        onClick={onClose}
      />

      {/* Modal */}
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <div className="bg-card rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
          {/* Header */}
          <div className="sticky top-0 bg-card border-b border-border flex items-center justify-between p-6">
            <h2 className="text-xl font-bold text-foreground">Product Details</h2>
            <button
              onClick={onClose}
              className="p-2 hover:bg-muted rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Content */}
          <div className="p-6">
            <div className="grid md:grid-cols-2 gap-8">
              {/* Image */}
              <div className="flex items-center justify-center bg-muted rounded-lg h-80">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover rounded-lg"
                />
              </div>

              {/* Details */}
              <div className="space-y-6">
                {/* Category */}
                <div>
                  <p className="text-xs font-mono text-muted-foreground uppercase tracking-wide mb-2">
                    {product.category}
                  </p>
                  <h3 className="text-2xl font-bold text-foreground mb-2">
                    {product.name}
                  </h3>
                  <p className="text-muted-foreground">{product.description}</p>
                </div>

                {/* Manufacturer */}
                <div>
                  <p className="text-xs font-mono text-muted-foreground uppercase tracking-wide mb-1">
                    Manufacturer
                  </p>
                  <p className="text-foreground font-semibold">{product.manufacturer}</p>
                </div>

                {/* Specifications */}
                <div>
                  <p className="text-xs font-mono text-muted-foreground uppercase tracking-wide mb-3">
                    Specifications
                  </p>
                  <div className="grid grid-cols-2 gap-2">
                    {product.specs.map((spec, idx) => (
                      <div
                        key={idx}
                        className="bg-muted p-3 rounded-lg border border-border"
                      >
                        <p className="text-xs font-mono text-muted-foreground">
                          {spec}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Stock Status */}
                <div className="p-4 bg-muted rounded-lg border border-border">
                  <p className="text-xs font-mono text-muted-foreground uppercase tracking-wide mb-2">
                    Availability
                  </p>
                  <div className="flex items-center justify-between">
                    <span className="text-foreground font-semibold">
                      {inStock ? (
                        <span className="text-accent flex items-center gap-2">
                          <Check className="w-4 h-4" />
                          In Stock ({product.stock} units)
                        </span>
                      ) : (
                        <span className="text-destructive">Out of Stock</span>
                      )}
                    </span>
                  </div>
                </div>

                {/* Price and CTA */}
                <div className="border-t border-border pt-6">
                  <div className="flex items-end justify-between mb-4">
                    <div>
                      <p className="text-xs font-mono text-muted-foreground uppercase tracking-wide mb-1">
                        Unit Price
                      </p>
                      <p className="text-3xl font-bold text-foreground">
                        ${product.price.toFixed(2)}
                      </p>
                    </div>
                  </div>
                  <Button
                    onClick={handleAddToCart}
                    disabled={!inStock}
                    size="lg"
                    className="w-full bg-accent hover:bg-accent/90 text-accent-foreground disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {added ? (
                      <>
                        <Check className="w-5 h-5 mr-2" />
                        Added to Cart
                      </>
                    ) : (
                      <>
                        <ShoppingCart className="w-5 h-5 mr-2" />
                        Add to Cart
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
