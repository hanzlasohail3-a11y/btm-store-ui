import { X } from 'lucide-react';
import { Product } from '@/hooks/useProductFilter';

interface ProductModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
}

export default function ProductModal({ product, isOpen, onClose }: ProductModalProps) {
  if (!isOpen || !product) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
      <div className="bg-white rounded-lg max-w-2xl w-full mx-4 overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-2xl font-bold text-gray-900">{product.name}</h2>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-900 transition"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 flex gap-8">
          {/* Product Image */}
          <div className="w-1/2">
            <div className="bg-gray-200 rounded-lg overflow-hidden h-80 flex items-center justify-center">
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663544340618/FBKg9EQwPBQ2VsXjCGoBKQ/electronics-components-7zymWBmLxNTSvRKjSuGGNc.webp"
                alt={product.name}
                className="w-full h-full object-cover"
              />
            </div>
          </div>

          {/* Product Details */}
          <div className="w-1/2 flex flex-col justify-between">
            <div>
              <p className="text-gray-600 text-sm mb-4">{product.specs}</p>

              {/* Stock Status */}
              <div className="mb-6">
                {product.inStock ? (
                  <span className="inline-block bg-green-100 text-green-800 text-sm font-semibold px-3 py-1 rounded">
                    In Stock
                  </span>
                ) : (
                  <span className="inline-block bg-red-100 text-red-800 text-sm font-semibold px-3 py-1 rounded">
                    Out of Stock
                  </span>
                )}
              </div>

              {/* Details */}
              <div className="space-y-4 mb-6">
                <div>
                  <h3 className="text-gray-700 font-semibold mb-2">Specifications</h3>
                  <p className="text-gray-600 text-sm">{product.specs}</p>
                </div>
                {product.category && (
                  <div>
                    <h3 className="text-gray-700 font-semibold mb-2">Category</h3>
                    <p className="text-gray-600 text-sm">{product.category}</p>
                  </div>
                )}
                {product.manufacturer && (
                  <div>
                    <h3 className="text-gray-700 font-semibold mb-2">Manufacturer</h3>
                    <p className="text-gray-600 text-sm">{product.manufacturer}</p>
                  </div>
                )}
              </div>
            </div>

            {/* Price and Action */}
            <div className="flex items-center justify-between pt-6 border-t border-gray-200">
              <span className="text-4xl font-bold text-gray-900">${product.price}</span>
              <button className="bg-orange-500 hover:bg-orange-600 text-white font-bold py-3 px-8 rounded transition">
                ADD TO CART
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
